<?php 
	// Strip any SQL tags and spaces from selected string
	function sanitizeFormString($inputText) {
		$inputText = strip_tags($inputText);
		$inputText = str_replace(" ", "", $inputText);
		$inputText = ucfirst(strtolower($inputText));
		return $inputText;
	}

	// -------------------STORE CHANGES-------------------
	if(isset($_GET['StoreAdd'])) {
		// Sanitize the strings input
		$itemName  = $_GET['ItemName'];
		$itemPrice = $_GET['ItemPrice'];
		$itemImage = $_GET['ItemImage'];

		// Save to Store Database
		$result = mysqli_query($con, "INSERT INTO $SQL_storeTable VALUES ('', '$itemName', '$itemPrice', '$itemImage')");
	}

 ?>