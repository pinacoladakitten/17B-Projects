<?php 
	$SQL_database = "ShoppingCart";
	$SQL_usersTable = "ajimerson_shop_entity_users";
	$SQL_storeTable = "ajimerson_shop_entity_store";
 ?>