<?php
	class Item{
		private $itemID;
		private $con;
		private $user;
		private $store;
		private $Qty=0;
		private $SQL_usersTable;
		private $SQL_storeTable;

		public function __construct($itemID, $con, $user, $store, $SQL_usersTable, $SQL_storeTable) {
			$this->itemID = $itemID;
			$this->con = $con;
			$this->user = $user;
			$this->store = $store;
			$this->SQL_usersTable = $SQL_usersTable;
			$this->SQL_storeTable = $SQL_storeTable;
		}

		public function GetQuantity(){
			$usersQuery = mysqli_query($this->con, "SELECT * FROM $this->SQL_usersTable WHERE username='$this->user'");
			$user = mysqli_fetch_array($usersQuery);

			$curItems = explode(",",$user['Cart']);

			for($i=0; $i < count($curItems); $i++){
				if($curItems[$i] == $this->itemID)$this->Qty++;
			}
			return $this->Qty;
		}
		public function GetName(){
			$storeQuery = mysqli_query($this->con, "SELECT * FROM $this->SQL_storeTable WHERE id=$this->itemID");
			$store = mysqli_fetch_array($storeQuery);

			return $store['itemName'];
		}
		public function GetPrice(){
			$storeQuery = mysqli_query($this->con, "SELECT * FROM $this->SQL_storeTable WHERE id=$this->itemID");
			$store = mysqli_fetch_array($storeQuery);

			return $store['price'];
		}
		public function GetImage(){
			$storeQuery = mysqli_query($this->con, "SELECT * FROM $this->SQL_storeTable WHERE id=$this->itemID");
			$store = mysqli_fetch_array($storeQuery);

			return $store['image'];
		}
		public function GetID(){
			$storeQuery = mysqli_query($this->con, "SELECT * FROM $this->SQL_storeTable WHERE id=$this->itemID");
			$store = mysqli_fetch_array($storeQuery);

			return $store['id'];
		}
	}
?>