<?php 
	include("includes/config.php");
	include("includes/mainHeader.php");
 ?>



<link rel="stylesheet" type="text/css" href="assets/css/main.css">
</head>
<body>
	<div id="backgroundMain">
		<div id="pageChoiceContainer">
			<h2>Welcome to the main page for 'Not a Shopping Cart'!</h2>

				<form id="userChoiceForm" action="main.php" method="POST">
					<button type="submit" name="EditAccount">Click here to Edit your Account</button>
					<button type="submit" name="BrowseStore">Click here to Browse the Store</button>
					<button type="submit" name="ViewCart">Click here to View Items in your Cart</button>
					<button type="submit" name="LogOut">LOG OUT</button>

					<?php 
						if(isset($_POST['EditAccount']))
						{
						     // View Account button was pressed
							//$usersQuery = mysqli_query($con, "SELECT id FROM users WHERE username='$userLoggedIn'");
							//$user = mysqli_fetch_array($usersQuery);

							header("Location: userInfo.php");
						}
						else if(isset($_POST['LogOut']))
						{
							session_destroy();
							header("Location: register.php");
						}
						else if(isset($_POST['BrowseStore']))
						{
							header("Location: cartMenu.php");
						}
						else if(isset($_POST['ViewCart']))
						{
							header("Location: cartView.php");
						}
				 	?>
			 	</form>
		</div>

	</div>

</body>
</html>