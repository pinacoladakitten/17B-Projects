<?php 
	include("includes/config.php");
	include("includes/mainHeader.php");
	include("includes/classes/Account.php");	// Account Class
	include("includes/classes/Item.php");		// Item Class

	// Create Account Class
	$account = new Account($con, $SQL_usersTable, $SQL_storeTable);
 ?>

	<link rel="stylesheet" type="text/css" href="assets/css/cartMenu.css">
</head>
<body>
	<div id="backgroundMain">

		<div id="pageChoiceContainer">
			<h2>Your Cart</h2>

			<form id="userChoiceForm" action="main.php" method="POST">
				<button type="submit" name="goBack">Click here to go back to the main page</button>
			</form>
			<br><br>

			<form id="cartAddForm" action="cartView.php" method="POST">
				<?php
					$usersQuery = mysqli_query($con, "SELECT * FROM $SQL_usersTable WHERE username='$userLoggedIn'");
					$user = mysqli_fetch_array($usersQuery);

					$curItems = array();
					if(strlen($user['Cart']) > 0) $curItems= explode(",", $user['Cart']);
					$itemQ = array();

					$totCost=0;

					if(count($curItems) > 0){
						for($i=0; $i < count($curItems); $i++){

							if(!in_array($curItems[$i], $itemQ)){
								$storeQuery = mysqli_query($con, "SELECT * FROM $SQL_storeTable WHERE id=$curItems[$i]");
								$store = mysqli_fetch_array($storeQuery);

								// Create Item Class
								$item = new Item($curItems[$i], $con, $userLoggedIn, $store, $SQL_usersTable, $SQL_storeTable);

								echo "<table>
										<div class='gridViewItem'>
											<tr>
												<th>Qty.</th>
												<th>Item Name</th>
												<th>Price</th>
											    <th>Preview</th> 
											    <th>Click to Remove</th> 
											</tr>
										 	<tr>
											    <td>".$item->GetQuantity()."</td>
											    <td>".$item->GetName()."</td>
											    <td>".$item->GetPrice()."</td>
											    <td>
										    		<img id='itemImg' src=".$item->GetImage().">
											    </td>
											    <td>
											    	<div class='delItem'>
														<button type='submit' name='delItem' value=".$item->GetID().">REMOVE</button>
													</div></td>
								  			</tr>
								  		</div>
									</table>";
								array_push($itemQ, $curItems[$i]);
							}

							$totCost+=$item->GetPrice();
						}
					}

					if(isset($_POST['delItem']) && count($curItems) > 0) {
						// Delete item...
						// Get the selected items through POST
						$selected = $_POST['delItem'];
						// Search in array for item and delete
						$idx = array_search($selected, $curItems);
						unset($curItems[$idx]);
						//Put item array back into SQL
						$myItems = implode(",", $curItems);
						$result = mysqli_query($con, "UPDATE $SQL_usersTable SET Cart='$myItems' WHERE username='$userLoggedIn'");
						header("Location: cartView.php");
					}

					echo "Total Cost: " . $totCost;
				?>
  				<br>
			</form>
		</div>
	</div>

</body>
</html>