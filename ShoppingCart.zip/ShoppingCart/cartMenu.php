<?php 
	include("includes/config.php");
	include("includes/mainHeader.php");
	include("includes/classes/Account.php");	// Account Class

	// Create Account Class
	$account = new Account($con, $SQL_usersTable, $SQL_storeTable);
 ?>

	<link rel="stylesheet" type="text/css" href="assets/css/cartMenu.css">
</head>
<body>
	<div id="backgroundMain">

		<div id="pageChoiceContainer">
			<h2>Take a look at our fantastic products!</h2>

			<form id="userChoiceForm" action="main.php" method="POST">
				<button type="submit" name="goBack">Click here to go back to the main page</button>
			</form>
			<br><br>

			<form id="cartAddForm" action="cartMenu.php" method="POST">
				<?php
					$storeQuery = mysqli_query($con, "SELECT * FROM $SQL_storeTable");
					$ItemQ = array();

					if(isset($_POST['addItem'])) {
						$selected = $_POST['addItem'];
						$storeQuery1 = mysqli_query($con, "SELECT * FROM $SQL_storeTable WHERE id='$selected'");
						$store = mysqli_fetch_array($storeQuery1);
						echo "Added: " . $store['itemName'] . "<br>";

						$usersQuery = mysqli_query($con, "SELECT * FROM $SQL_usersTable WHERE username='$userLoggedIn'");
						$user = mysqli_fetch_array($usersQuery);

						if(strlen($user['Cart'])>0)$ItemQ = explode(",",$user['Cart']);
						array_push($ItemQ, $selected);

						$currItems = implode(",", $ItemQ);

						$result = mysqli_query($con, "UPDATE $SQL_usersTable SET Cart='$currItems' WHERE username='$userLoggedIn'");
					}

					while($store = mysqli_fetch_array($storeQuery)){
						echo "<table>
								<div class='gridViewItem'>
									<tr>
										<th>Item Name</th>
										<th>Price</th>
									    <th>Preview</th> 
									    <th>Click to Add</th> 
									</tr>
								 	<tr>
									    <td> ".$store['itemName']." </td>
									    <td> ".$store['price']." </td>
									    <td>
								    		<img id='itemImg' src=" . $store['image'] . ">
									    </td>
									    <td>
									    	<div class='addItem'>
												<button type='submit' name='addItem' value=".$store['id'].">ADD</button>
											</div></td>
						  			</tr>
						  		</div>
							</table>";
					}
  				?>
  				<br>
		</div>

	</div>

</body>
</html>